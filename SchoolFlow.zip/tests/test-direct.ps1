﻿# ============================================================
# SchoolFlow — Test direct Phase 7+
# VERSION COMPATIBLE WINDOWS POWERSHELL 5.1
# ============================================================

param(
    [string]$BaseUrl = "https://localhost:5294"
)

# --- FORCE LA CONNEXION HTTPS MALGRÉ LE CERTIFICAT NON VALIDE ---
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
[Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }

$pass = 0; $fail = 0

# Fonction pour remplacer l'opérateur ??
function Coalesce($primary, $secondary) {
    if ($null -ne $primary) { return $primary }
    return $secondary
}

function Post($path, $body, $token = "") {
    $h = @{ "Content-Type" = "application/json" }
    if ($token) { $h["Authorization"] = "Bearer $token" }
    try {
        # Suppression de -SkipHttpErrorCheck et -SkipCertificateCheck
        $r = Invoke-WebRequest -Method POST -Uri "$BaseUrl$path" `
            -Body ($body | ConvertTo-Json -Depth 5) -Headers $h
        return @{ Status = [int]$r.StatusCode; Data = ($r.Content | ConvertFrom-Json) }
    } catch {
        # En PS 5.1, on récupère le code HTTP depuis l'exception
        $status = 0
        if ($_.Exception.Response) {
            $status = [int]$_.Exception.Response.StatusCode.value__
            # On tente de lire le corps de la réponse d'erreur
            $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
            $content = $reader.ReadToEnd()
            try { $data = $content | ConvertFrom-Json } catch { $data = $content }
        }
        return @{ Status = $status; Error = $_.Exception.Message; Data = $data }
    }
}

function Get($path, $token = "") {
    $h = @{}
    if ($token) { $h["Authorization"] = "Bearer $token" }
    try {
        $r = Invoke-WebRequest -Method GET -Uri "$BaseUrl$path" -Headers $h
        return @{ Status = [int]$r.StatusCode; Data = ($r.Content | ConvertFrom-Json) }
    } catch {
        $status = 0
        if ($_.Exception.Response) {
            $status = [int]$_.Exception.Response.StatusCode.value__
            $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
            $content = $reader.ReadToEnd()
            try { $data = $content | ConvertFrom-Json } catch { $data = $content }
        }
        return @{ Status = $status; Error = $_.Exception.Message; Data = $data }
    }
}

function OK($label, $cond, $info = "") {
    $fullMsg = $label
    if ($info) { $fullMsg = "$label - $info" }

    if ($cond) {
        Write-Host "  [PASS] $fullMsg" -ForegroundColor Green
        $script:pass++
    } else {
        Write-Host "  [FAIL] $fullMsg" -ForegroundColor Red
        $script:fail++
    }
}

function Section($title) { 
    Write-Host "`n--- $title ---" -ForegroundColor Cyan 
}

# ============================================================
Section "TEST 1 - LOGIN ADMIN"
# ============================================================

$login = Post "/api/auth/login" @{ username = "admin.victoire"; password = "Admin@2025" }
OK "Login admin.victoire -> 200" ($login.Status -eq 200) "Status=$($login.Status)"

if ($login.Status -ne 200) {
    Write-Host "  Login echoue - impossible de continuer." -ForegroundColor Red
    Write-Host "  Erreur : $($login.Error)" -ForegroundColor DarkRed
    Write-Host "  Reponse : $($login.Data | ConvertTo-Json)" -ForegroundColor DarkRed
    exit 1
}

$token    = $login.Data.token
$ecoleId  = $login.Data.ecoleId
OK "EcoleId non vide" ($ecoleId -and $ecoleId -ne "00000000-0000-0000-0000-000000000000") "ecoleId=$ecoleId"

# ============================================================
Section "TEST 2 - CREER ANNEE SCOLAIRE"
# ============================================================

$anneeResult = Post "/api/annees-scolaires" @{
    libelle              = "2025-2026-test-$(Get-Random -Max 9999)"
    dateDebut            = "2025-09-01T00:00:00Z"
    dateFin              = "2026-07-31T00:00:00Z"
    typePeriode          = "Trimestre"
    activerImmediatement = $false
} -token $token

OK "POST /annees-scolaires -> 200/201" ($anneeResult.Status -in @(200, 201)) "Status=$($anneeResult.Status)"

if ($anneeResult.Status -notin @(200, 201)) {
    Write-Host "  Reponse : $($anneeResult.Data | ConvertTo-Json -Depth 3)" -ForegroundColor DarkRed
}

$anneeId = Coalesce $anneeResult.Data.data $anneeResult.Data

# ============================================================
Section "TEST 3 - LISTER ANNEES"
# ============================================================

$annees = Get "/api/annees-scolaires" -token $token
OK "GET /annees-scolaires -> 200" ($annees.Status -eq 200) "Status=$($annees.Status)"
$dataAnnees = Coalesce $annees.Data.data $annees.Data
$count = if ($dataAnnees -is [array]) { $dataAnnees.Count } else { 0 }
OK "Au moins 1 annee retournee" ($count -gt 0) "Count=$count"

# ============================================================
Section "TEST 4 - CREER CLASSE"
# ============================================================

if ($anneeId) {
    $classe = Post "/api/classes" @{
        code            = "CM2-TEST-$(Get-Random -Max 999)"
        nom             = "CM2 Test"
        niveau          = "CM2"
        sousSysteme     = "Francophone"
        section         = "T"
        capaciteMax     = 40
        anneeScolaireId = "$anneeId"
    } -token $token

    OK "POST /classes -> 200/201" ($classe.Status -in @(200, 201)) "Status=$($classe.Status)"
    if ($classe.Status -notin @(200, 201)) {
        Write-Host "  Reponse : $($classe.Data | ConvertTo-Json -Depth 3)" -ForegroundColor DarkRed
    }
} else {
    Write-Host "  [SKIP] Pas d'anneeId disponible" -ForegroundColor Yellow
}

# ============================================================
Section "TEST 5 - LISTER FAMILLES"
# ============================================================

$familles = Get "/api/familles" -token $token
OK "GET /familles -> 200" ($familles.Status -eq 200) "Status=$($familles.Status)"
if ($familles.Status -eq 200) {
    $dataFam = Coalesce $familles.Data.data $familles.Data
    $count = if ($dataFam -is [array]) { $dataFam.Count } else { 0 }
    Write-Host "       Familles retournees : $count" -ForegroundColor DarkGray
}

# ============================================================
Section "TEST 6 - DASHBOARD"
# ============================================================

$dash = Get "/api/dashboard/stats" -token $token
OK "GET /dashboard/stats -> 200" ($dash.Status -eq 200) "Status=$($dash.Status)"
if ($dash.Status -eq 200) {
    $d = Coalesce $dash.Data.data $dash.Data
    Write-Host "       TotalEleves=$($d.totalEleves) TotalFamilles=$($d.totalFamilles)" -ForegroundColor DarkGray
}

# ============================================================
Section "TEST 7 - ISOLATION TENANT (SuperAdmin)"
# ============================================================

$loginSA = Post "/api/auth/login" @{ username = "superadmin"; password = "SuperAdmin@2025" }
if ($loginSA.Status -eq 200) {
    $tokenSA = $loginSA.Data.token

    $r = Get "/api/familles" -token $tokenSA
    OK "SuperAdmin GET /familles -> 403" ($r.Status -eq 403) "Status=$($r.Status)"

    $r = Get "/api/dashboard/stats" -token $tokenSA
    OK "SuperAdmin GET /dashboard/stats -> 403" ($r.Status -eq 403) "Status=$($r.Status)"

    $r = Get "/api/ecoles" -token $tokenSA
    OK "SuperAdmin GET /ecoles -> 200" ($r.Status -eq 200) "Status=$($r.Status)"
} else {
    Write-Host "  [SKIP] Login SuperAdmin echoue" -ForegroundColor Yellow
}

# ============================================================
Section "TEST 8 - TYPES DE FRAIS"
# ============================================================

$tf = Get "/api/types-frais" -token $token
OK "GET /types-frais -> 200" ($tf.Status -eq 200) "Status=$($tf.Status)"
if ($tf.Status -eq 200) {
    $dataTf = Coalesce $tf.Data.data $tf.Data
    $count = if ($dataTf -is [array]) { $dataTf.Count } else { 0 }
    Write-Host "       Types de frais : $count" -ForegroundColor DarkGray
}

# ============================================================
Write-Host "`n===============================================" -ForegroundColor Cyan
$color = if ($fail -gt 0) { "Red" } else { "Green" }
Write-Host "  RESULTAT : $pass PASS | $fail FAIL" -ForegroundColor $color
Write-Host "===============================================" -ForegroundColor Cyan

if ($fail -gt 0) { exit 1 }
